import requests
import json
from datetime import datetime

url = "https://api.kcg.gov.tw/api/service/get/ad197194-6db9-4f14-ad38-2adceea831c3"
r = requests.get(url)
data1 = json.loads(r.text)
car_data = data1['data']

def custom_sort_key(item):
        date_str = item['發生日期']
        date_str = date_str.replace('上午', 'am').replace('下午', 'pm')
        date_obj = datetime.strptime(date_str, "%Y/%m/%d %p %I:%M:%S")
        formatted_date_str = datetime.strftime(date_obj, "%Y/%m/%d %H:%M:%S")
        return formatted_date_str

    # Sort car_data by custom key function
sorted_data = sorted(car_data, key=custom_sort_key)


for item in sorted_data:
    print(item['發生日期'])